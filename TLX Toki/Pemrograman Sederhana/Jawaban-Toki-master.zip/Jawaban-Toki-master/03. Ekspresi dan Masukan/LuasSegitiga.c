#include <stdio.h>
int main () {
	float alas, tinggi, luas;
	scanf("%f %f",&alas, &tinggi);
	luas= alas*tinggi/2;
	printf("%.2f\n",luas);
}
